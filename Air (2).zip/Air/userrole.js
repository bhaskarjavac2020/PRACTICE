const postsList = document.querySelector('.posts-list');
const addPostForm = document.querySelector('.add-post-form');

const url = 'http://164.52.212.42:8085/as-admin/admin/getSingleUserRole?id=';